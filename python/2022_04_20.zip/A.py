
import os
os.system('cls')

print('---------------------------')
print('Kocka felszíne és térfogata')
print('---------------------------')
print('Add meg a kocka oldalának a hosszát cm-ben!')
a = int(input("a= "))

print('   __________')
print('  /         /|')
print(' /         / |')
print('/_________/  |')
print('|         |  |')
print('|         |  /')
print('|         | /')
print('|_________|/')
A = (a * a) * 6
V = a * a * 5
print('A=  ' + str(A) + ' cm2')
print('V=  ' + str(V) + ' cm3')
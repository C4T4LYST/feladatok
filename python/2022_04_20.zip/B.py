import os
os.system('cls')

print('====================')
print('100-hoz viszonyítás')
print('====================')
print('Adj meg egy számot és kiírom, 100-nál kisebb, nagyobb, bóvagy egyenlő-e vele!')
a = int(input('Kérek egyy számot: '))

if a == 100:
    print('A szám egyenlő 100-zal')
elif a > 100:
    print('A szám nagyobb 100-nál')
else:
    print('A szám kisebb 100-nál')

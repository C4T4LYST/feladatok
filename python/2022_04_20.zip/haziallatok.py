import os
os.system('cls')
print('Lista elemek beolvasása:')

fl = open('haziallat.txt', 'r', encoding='utf-8')

ls = []
for asd in fl:
    jl = asd.split(';')
    ls.append((jl[0], int(jl[1])))

fl.close()

for ias in ls:
    nev = ias[0]
    szam = ias[1]
    print(nev + ' ' + str(szam))

print('Ennyi ember található a listában: ' + str(len(ls)))
nthr = 0
for ias in ls:
    if(ias[1] > 3):
        nthr += 1

print('Ennyi embernek van 3-nál több háziállata: ' + str(nthr))

sv = open('kiiratas.txt', 'w', encoding='utf-8')
sv.write('Lista elemek beolvasása:' + '\n')

for ias in ls:
    nev = ias[0]
    szam = ias[1]
    sv.write(nev + ' ' + str(szam) + '\n')

sv.write('Ennyi ember található a listában: ' + str(len(ls)) + '\n')
sv.write('Ennyi embernek van 3-nál több háziállata: ' + str(nthr))
sv.close()